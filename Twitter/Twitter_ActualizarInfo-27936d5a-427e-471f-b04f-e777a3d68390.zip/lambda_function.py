import json
import pymysql

# Configuración de la base de datos
rds_endpoint = '44.205.178.122'
db_username = 'twitter'
db_password = 'twitter'
db_name = 'twitter'

def lambda_handler(event, context):
    # Establecer conexión con la base de datos
    try:
        conn = pymysql.connect(host=rds_endpoint, user=db_username, passwd=db_password, db=db_name, cursorclass=pymysql.cursors.DictCursor)
    except pymysql.MySQLError as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # Necesario para CORS
            },
            'body': json.dumps({'error': 'Error connecting to the database', 'details': str(e)})
        }
    
    try:
        # Aquí asumimos que el evento viene con el ID del usuario en los parámetros de la query string
        user_id = event.get('queryStringParameters', {}).get('userId')
        if not user_id:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'Missing userId in the request'})
            }
        
        # Obtener la información del usuario
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM usuarios WHERE ID = %s", (user_id,))
            user_info = cursor.fetchone()

        # Asegúrate de que se encontró al usuario
        if not user_info:
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'User not found'})
            }

        # Obtener los tweets del usuario
        with conn.cursor() as cursor:
            cursor.execute("SELECT mensaje FROM mensajes WHERE idUsuario = %s", (user_id,))
            tweets = cursor.fetchall()
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'user_info': user_info, 'tweets': tweets})
        }
        
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Error processing the request', 'details': str(e)})
        }
    finally:
        conn.close()
