import json
import pymysql
import logging

# Configuración del logger para depuración
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # Puedes cambiar a DEBUG para más detalle

# Configuración de la base de datos RDS
rds_endpoint = '44.205.178.122'
db_username = 'twitter'
db_password = 'twitter'
db_name = 'twitter'

def lambda_handler(event, context):
    # Intenta establecer la conexión a la base de datos
    try:
        conn = pymysql.connect(
            host=rds_endpoint,
            user=db_username,
            passwd=db_password,
            db=db_name,
            connect_timeout=5
        )
        logger.info("Conexión a base de datos establecida")
    except pymysql.MySQLError as e:
        logger.error(f"Error al conectar a MySQL: {e}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps("Error al conectar a la base de datos")
        }

    # Parsea el cuerpo de la solicitud
    try:
        body = json.loads(event['body'])
        id_usuario = body['idUsuario']
        mensaje = body['mensaje']
        dato_adjunto = body.get('datoAdjunto')
        tipo_dato = body.get('tipoDato')

        with conn.cursor() as cursor:
            sql = """
            INSERT INTO mensajes (idUsuario, mensaje, datoAdjunto, tipoDato)
            VALUES (%s, %s, %s, %s)
            """
            cursor.execute(sql, (id_usuario, mensaje, dato_adjunto, tipo_dato))
            conn.commit()
        logger.info("Mensaje insertado correctamente")

        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps("Mensaje insertado con éxito")
        }
    except Exception as e:
        logger.error(f"Error al procesar la solicitud: {e}")
        return {
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps("Error al insertar el mensaje")
        }
    finally:
        conn.close()  # Asegúrate de cerrar la conexión a la base de datos