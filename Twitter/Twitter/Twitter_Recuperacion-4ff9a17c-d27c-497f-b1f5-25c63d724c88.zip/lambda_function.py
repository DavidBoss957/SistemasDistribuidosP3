import json
import pymysql
import logging

# Configuración del logger para depuración
logger = logging.getLogger()
logger.setLevel(logging.INFO)

rds_endpoint = '44.205.178.122'  # Endpoint de tu base de datos
db_username = 'twitter'          # Usuario de la base de datos
db_password = 'twitter'          # Contraseña de la base de datos
db_name = 'twitter'              # Nombre de la base de datos

def lambda_handler(event, context):
    conn = None  # Inicializa conn a None
    try:
        # Parsea el cuerpo de la solicitud
        body = json.loads(event['body'])
        recover_password = body['recover_password']

        # Conexión a la base de datos
        conn = pymysql.connect(host=rds_endpoint, user=db_username, passwd=db_password, db=db_name, connect_timeout=5)
        with conn.cursor() as cursor:
            cursor.execute("SELECT password FROM usuarios WHERE recover_password = %s", (recover_password,))
            result = cursor.fetchone()
            if result:
                return {
                    'statusCode': 200,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({'password': result[0]})
                }
            else:
                return {
                    'statusCode': 400,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps('Palabra clave no encontrada')
                }
    except pymysql.MySQLError as e:
        logger.error(f"Error al conectar a MySQL: {e}")
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps("Error al conectar a la base de datos")
        }
    except KeyError:
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps("Campo 'recover_password' faltante")
        }
    finally:
        if conn:  # Cierra la conexión si conn no es None
            conn.close()
