import json
import pymysql
import os

# Configuración de la base de datos
db_endpoint = os.environ.get('44.205.178.122')  # Deberías configurar tus variables de entorno en AWS Lambda
db_username = os.environ.get('twitter')
db_password = os.environ.get('twitter')
db_name = os.environ.get('twitter')

def lambda_handler(event, context):
    # Supongamos que el ID del usuario se pasa como un parámetro de consulta
    user_id = event['queryStringParameters']['id']
    
    try:
        # Establecer conexión con la base de datos
        conn = pymysql.connect(
            host=db_endpoint,
            user=db_username,
            passwd=db_password,
            db=db_name,
            connect_timeout=5,
            cursorclass=pymysql.cursors.DictCursor
        )
        
        with conn.cursor() as cursor:
            # Recuperar la información del usuario
            cursor.execute("SELECT * FROM usuarios WHERE ID = %s", (user_id,))
            user_data = cursor.fetchone()
            
            # Si user_data es None, el usuario no se encontró
            if user_data is None:
                return {
                    'statusCode': 404,
                    'headers': {'Content-Type': 'application/json'},
                    'body': json.dumps({'error': 'Usuario no encontrado'})
                }
            
            return {
                'statusCode': 200,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps(user_data)
            }
    
    except pymysql.MySQLError as e:
        print(e)
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Error al conectar con la base de datos'})
        }
    finally:
        if conn:
            conn.close()
