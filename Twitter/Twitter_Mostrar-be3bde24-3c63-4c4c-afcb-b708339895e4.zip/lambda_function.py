import json
import pymysql
import logging

# Configure logging for debugging
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # You can change this to DEBUG for more detailed output

# Database configuration
rds_endpoint = '44.205.178.122'
db_username = 'twitter'
db_password = 'twitter'
db_name = 'twitter'

# Lambda handler function
def lambda_handler(event, context):
    # Attempt to establish a connection to the database
    try:
        conn = pymysql.connect(
            host=rds_endpoint,
            user=db_username,
            passwd=db_password,
            db=db_name,
            connect_timeout=5,
            cursorclass=pymysql.cursors.DictCursor  # Use DictCursor to get dictionaries
        )
        logger.info("Successfully connected to the database.")
    except pymysql.MySQLError as e:
        logger.error(f"Error connecting to MySQL: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # Allow any domain, adjust in production
            },
            'body': json.dumps({"error": "Error connecting to the database"})
        }

    # Attempt to execute the query and fetch messages
    try:
        with conn.cursor() as cursor:
            query = """
            SELECT mensajes.idMensaje, usuarios.nombre_usuario, mensajes.mensaje
            FROM mensajes
            INNER JOIN usuarios ON mensajes.idUsuario = usuarios.ID
            """
            cursor.execute(query)
            result = cursor.fetchall()  # Fetch all results from the query

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # CORS header
            },
            'body': json.dumps(result)
        }
    except Exception as e:
        logger.error(f"Error fetching messages: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # CORS header
            },
            'body': json.dumps({"error": "Error fetching messages"})
        }
    finally:
        if conn:
            conn.close()  # Make sure to close the database connection
